import json

import DynamoDb, Sns
import Sqs


def salary_calculator_handler(event, context):
    message = json.loads(event)
    Sns.publish_message_to_sns(message)
    messages_from_queue = json.loads(Sqs.read_message_from_queue())
    monthly_gross = messages_from_queue['amount']
    uuid = messages_from_queue['uuid']
    DynamoDb.save_data(monthly_gross, uuid)
    return messages_from_queue
