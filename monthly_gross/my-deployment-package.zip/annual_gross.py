import uuid
import boto3


def annual_gross_handler(event):
    dynamodb = boto3.client('dynamodb')
    dynamodb.put_item(TableName='annual_gross',
                      Item={'id': {'S': str(uuid.uuid4())}, 'amount': {'N': event['amount']},
                            'description': {'S': 'Annual gross'}})
    return {'Annual gross': event['amount']}
