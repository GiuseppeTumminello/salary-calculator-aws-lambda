import uuid
import boto3

dynamodb = boto3.client('dynamodb')
total_zus_rate = 0.1371
health_rate = 0.09
annual_threshold = 120000
tax_rate_17 = 0.0832
tax_rate_32 = 0.1432
month = 12


def annual_net_handler(event, context):
    annual_net = calculate_net(event['amount'])
    dynamodb.put_item(TableName='annual_net',
                      Item={'id': {'S': str(uuid.uuid4())}, 'amount': {'N': str(annual_net)},
                            'description': {'S': 'Annual gross'}})
    return {'Annual net': annual_net}


def calculate_total_zus(monthly_gross):
    return monthly_gross * total_zus_rate


def calculate_health(monthly_gross):
    return calculate_total_zus(monthly_gross) * health_rate


def calculate_net(monthly_gross):
    if monthly_gross * month < annual_threshold:
        calculate_health(monthly_gross) * tax_rate_17
    else:
        return calculate_health(monthly_gross) * tax_rate_32
