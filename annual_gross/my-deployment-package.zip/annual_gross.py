import uuid

import boto3

month = 12
sqs = boto3.client('sqs')
queue_url = 'https://sqs.us-east-1.amazonaws.com/342003767516/salary-calculator-orchestrator-queue'


def send_message_to_queue(self):
    sqs.send_message(QueueUrl=queue_url, MessageAttributes={'amount': self, })


def annual_gross_handler(event, context):
    dynamodb = boto3.client('dynamodb')
    annual_gross = event['amount'] * month
    send_message_to_queue(annual_gross)
    dynamodb.put_item(TableName='annual_gross',
                      Item={'id': {'S': str(uuid.uuid4())}, 'amount': {'N': annual_gross},
                            'description': {'S': 'Annual gross'}})
    return {'Annual gross': annual_gross}
